# Data dictionary

All CSV files use a header row and comma-separated UTF-8 text. Empty cells mean unavailable/not supplied, never zero. A numeric zero is an observed or reported zero at the stored precision. JSON has the supplied nested structure.

## author-results.csv

One author-supplied summary per configuration, with the final VOC 10-5 baseline corrected on 2026-10-22 as recorded in provenance.json. `dataset`: VOC or COCO-to-VOC. `protocol`: overlap, disjoint, transfer, or joint; joint is a full-data reference, not incremental learning. `task`: initial/added foreground counts, e.g. 10-5 or 60-20. `method`: supplied method/configuration label, including hyperparameter variants. `old`, `new`, `all`: mIoU (%) for the fixed initial foreground group, all introduced foreground classes, and all classes including background. `voc_new`: incoming-class mIoU (%) on separate VOC validation for COCO-to-VOC. `iterations`: supplied incremental training iteration count for the disjoint SASA runs only; empty elsewhere does not mean zero updates. The final two result-less control rows are unused placeholders; see shared-weight-controls.csv.

The file mixes unrounded/partly rounded author precision and one-decimal ablations. It includes the authors' own disjoint SASA runs and their COCO Joint (ViT) measurement, not a claim that every row describes EvoProto or a public benchmark result.

## baseline-voc10-5.csv

Final (step 2) overlap VOC 10-5 baseline. `class`: standard VOC category name, `_background_`, or the aggregate marker `mIoU`. `CAM`, `aux_CAM`, `Seg_Pred`: main CAM, auxiliary CAM and final segmentation IoU (%), respectively, evaluated for each category. The `mIoU` row is the all-class aggregate, including background. Only `Seg_Pred` is the final segmentation score used in the baseline comparison. It should not be confused with either CAM score. On 2026-10-22, the author corrected final chair `Seg_Pred` from 44.378 to 39.7 in this same run; the all-class `Seg_Pred` mIoU was recomputed as 68.298. The CAM columns and all other class IoUs are unchanged.

## evoproto-voc10-5.json

Final (step 2) overlap VOC 10-5 EvoProto. `old_miou`: classes 1–10 foreground mean; `new_miou`: classes 11–20 foreground mean; `all_miou`: mean over all 21 classes including background; `foreground_miou`: mean over 20 foreground categories. `class_iou`: category-name to IoU (%) mapping, including `_background_`.

## voc10-5-stage-results.json

`dataset`, `protocol`: evaluation identity. `class_groups`: ordered foreground names for `base10`, `step1_new` (classes 11–15), `step2_new` (16–20). `stages`: step strings `0`, `1`, `2`, each with Baseline and EvoProto. `class_iou`: per-class IoU (%) including `background`. `reported_summary`: the supplied aggregate values, with the final baseline Old/All values recomputed to 74.924/68.298 for the author-confirmed 2026-10-22 chair correction. `derived_summary`: arithmetic means recomputed from stored class values: `foreground_miou` excludes background; `all_miou` includes it; `base10_miou` always uses the original 10; `preceding_classes_miou` uses the foreground learned before this update; `newly_added_classes_miou` uses the current update's five new classes. `reported_summary.old_miou` retains the fixed-base 10-class definition. At final step 2, `reported_summary.new_miou` uses all 10 post-base classes, not only step2_new. Consequently it differs from `newly_added_classes_miou`. A derived summary may differ slightly from a rounded reported summary.

`pair_diagnostics`: selected old/new class pairs at `update` (e.g. 0->1); `old_class`, `new_class` give category names. Each method has `old_before`, `old_after`, `new_after` (IoU %), and `old_change` (after minus before, percentage points, computed before rounding). No cosine scores/prototype vectors are stored in this JSON.

## resource-step1.csv

First incremental step of overlap VOC 10-5, single RTX 4090, FP32, 448x448 input, batch 8. `method`: Baseline or EvoProto; `stage`: step1. `trainable_params_m`: trainable parameters in millions. `forward_gflops_batch8`: GFLOPs for one forward **batch of 8**, not per image or a full training update. `peak_memory_mb`: peak memory in the supplied MB unit (the source does not specify decimal/binary convention). `network_seconds_per_update`: network-update time in seconds, excluding the extra confusion-estimation accounting. `estimated_8000_training_minutes`: estimated duration of 8,000 updates in minutes, including confusion-estimation cost. It is not a raw wall-clock trace. `device`, `precision`, `input_size`, `batch_size`: profiling conditions. The given per-update network time cannot on its own reconstruct the full estimated duration.

## step2-overwriting.csv

Final step-2 overlap VOC 10-5 old-to-new prediction-error rates (%), **lower is better**. `class`: one of the 15 foreground classes learned before step 2. `Baseline`: baseline; `CAPE`: Baseline+CAPE; `Full`: EvoProto. The denominator is the ground-truth pixel count of that old class; the numerator includes predictions in any of the final five new categories. See README for the full definition and macro-average distinction. `chair` includes the author-corrected 4.646/3.579 CAPE/Full values.

## hyperparameter-sensitivity.csv

Final-step overlap VOC 10-5 one-variable sweeps. `parameter`: `K` (confusion-weight temperature), `rho` (EBR strength), `lambda_cl` (RCPL coefficient), `lambda_kd` (CPA coefficient). `value`: dimensionless parameter value. `is_default`: 1 for the shared default setting and 0 otherwise. `source_method`: matching method label in author-results.csv. `old`, `new`, `all`: mIoU (%), rounded to one decimal for plotting. `delta_old`, `delta_new`, `delta_all`: percentage-point changes from 79.2/66.9/74.0, computed from these displayed one-decimal values, **not** differences of unrounded raw scores. The repeated default row across four sweeps represents the same default result, not four independent runs. Other parameters remain K=0.5, rho=1, lambda_cl=lambda_kd=0.1.

## shared-weight-controls.csv

Final-step overlap VOC 10-5 controls retaining EBR rho=1. `dataset`, `protocol`, `task`, `stage`: evaluation identity. `configuration`: the current manuscript row name. `rcpl_weighting`, `cpa_weighting`: Uniform, Adaptive, or Permuted. `ebr_rho`: fixed EBR strength. `old_miou`, `new_miou`, `all_miou`: measured mIoU (%) at manuscript one-decimal precision; old=classes 1–10, new=11–20, all includes background. `data_status`, `source`: author confirmation and manuscript provenance. Uniform constraints average each loss's coefficients at each weight update. Uniform CPA keeps RCPL adaptive and only averages CPA. Mismatched CPA applies a fixed within-step permutation of old foreground alignment weights, leaving RCPL/background weights intact. EvoProto shares class-specific adaptive weights. No unrounded scores, background assumptions, or independent-run statistics are inferred.

## manuscript-aggregates.csv

Existing author-result aggregates transcribed from the current manuscript at their displayed precision. `dataset`, `protocol`, `task`, `stage`: the context. `analysis`: prototype-pair diagnostic, confusion-estimate agreement, confusion-reference diagnostic, or joint reference. `condition`: manuscript condition name. `class_pair`: the two category names where relevant; empty for non-pair analyses. `metric`: prototype cosine similarity, pair mIoU, same top-1 counterpart, rank correlation, or Old/New/All mIoU. `value`: displayed numerical value. `unit`: percent (mIoU), percent of classes (counterpart agreement), or dimensionless (cosine/rank correlation). `source`: manuscript table/subsection provenance.

Prototype-pair conditions retain the manuscript labels Fully supervised, Weakly supervised, and Weakly supervised + EvoProto. The paired mIoU averages the two named classes. The weakly supervised final chair/dining-table pair was corrected from 39.5 to 37.1 after the author corrected final baseline chair IoU to 39.7. The confusion-agreement comparison uses the same model predictions with merged pseudo-labels or ground-truth masks as reference; 80.0% is a class-level agreement, not pixel accuracy. The ground-truth-confusion mIoU rows describe a diagnostic training condition, not accessible supervision for the proposed weakly supervised method. The VOC Joint (Transformer) rows are a full-data author-measured reference. The same joint reference is reused across incremental protocols (and reported under their initial/introduced class partitions); these rows are not independent incremental training runs. Joint mIoU uses the same foreground/background definitions described in README. No raw vectors, matrices, prediction masks, or unrounded trial outputs are reconstructed.

## training-configuration.json

A machine-readable record of selected reported settings, not a runnable configuration. `backbone` includes architecture/initialization and auxiliary-head block; `optimizer` includes name, implementation name, betas, epsilon, and weight decay; `learning_rate` includes base/incremental values and scheduler; `stage_iterations` gives stage budgets; `input_crop_pixels`, `batch_size`, `cam_thresholds`, `ignore_index` specify documented inputs/target handling; `objective` stores the three objective coefficients, K and rho; the activation/update fields store the delayed segmentation/EBR/confusion schedule. `gpu_model` and `resource_profile_precision` record documented profiling hardware/precision. `not_recorded_in_this_package` is an explicit coverage list. All thresholds, coefficients and optimizer epsilon are dimensionless; learning rates use the optimizer's conventional scalar unit; update/iteration counts are integers.

## provenance.json and checksums.sha256

`provenance.json` records the origin and current SHA-256 of each of the seven source data files without personal/local absolute paths. Its historical `original_files` key contains both unchanged and author-corrected source records, distinguished by `status`; corrected records retain `prior_sha256`, prior/corrected values, and the author confirmation date. Transcribed data files and the correction to the chair/dining-table pair are identified separately. `checksums.sha256` gives SHA-256 and a package-relative filename for every payload file except itself. The zip container is outside its own payload and does not checksum itself.
