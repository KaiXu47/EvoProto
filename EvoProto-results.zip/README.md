# EvoProto aggregate experimental results

By Fang Kai.

Supporting aggregate results for *EvoProto: Confusion-Aware Prototype Evolution for Weakly Supervised Incremental Segmentation*, prepared for the Neural Networks manuscript. This package contains author-supplied numerical summaries and selected documented settings. It is **not** the original training-image dataset, a checkpoint release, a source-code release, or a pixel-level prediction archive.

## Files and provenance

The seven supplied CSV/JSON source files in `data/` match the current manuscript workspace. Four retain the previously supplied bytes; three include the author-confirmed 2026-10-22 correction described below. Unaffected fields, missing cells, and reported/derived distinctions are preserved. `shared-weight-controls.csv` transcribes the current shared-weight table: the authors confirmed that its four rows are measured results. It keeps the displayed one-decimal precision; no background values or extra precision are reconstructed. `manuscript-aggregates.csv` transcribes additional existing aggregate diagnostics and the author-measured VOC joint transformer references at their displayed precision. `training-configuration.json` records settings supplied by the authors or already stated in the manuscript. The data dictionary explains every file and field.

The final two rows of `author-results.csv` have empty result cells for uniform-constraint and mismatched-CPA controls. These are historical unfilled placeholders, not measured zero scores. Use `shared-weight-controls.csv` for these controls and Uniform CPA.

## Author correction, 2026-10-22

The author confirmed that final-step baseline chair segmentation IoU is **39.7%**, correcting 44.378% in the same VOC 10-5 run. The other 20 class IoUs are unchanged. Recomputed baseline Old/New/All mIoU is 74.924/59.4519/68.298% (All before rounding: 68.29838095238095%). The chair decline from step 1 is 15.03 points, and final chair/dining-table pair mIoU is 37.124%, reported as 37.1%. The baseline CSV, stage/pair JSON, summary CSV, and manuscript pair aggregate have been synchronized. `provenance.json` retains the prior values and SHA-256 hashes for the three corrected source files. This correction does not alter the CAM scores, EvoProto measurements, or old-to-new prediction-error rates.

## Protocols and units

Scores named IoU or mIoU are percentages on a 0–100 scale; a score difference is in percentage points. Cosine scores and rank correlations are dimensionless. No standard deviations, seed counts, significance tests, or confidence intervals are supplied here.

VOC uses the standard foreground order shown below. The base stage is step 0. In 10–5, step 0 learns classes 1–10, step 1 adds 11–15, and step 2 adds 16–20. In 10–10 and 15–5 there is one update; 10–2 has five updates. The disjoint protocol excludes future classes from earlier training stages; overlap allows them to appear before their labels are introduced. The base stage uses dense supervision, and incremental new classes use image-level labels.

1. aeroplane; 2. bicycle; 3. bird; 4. boat; 5. bottle; 6. bus; 7. car; 8. cat; 9. chair; 10. cow; 11. diningtable; 12. dog; 13. horse; 14. motorbike; 15. person; 16. pottedplant; 17. sheep; 18. sofa; 19. train; 20. tvmonitor.

For the main VOC summary rows, **Old** averages the initial foreground classes and **New** averages every foreground class introduced after the base stage. **All** also includes background (21 classes at the final VOC stage). Thus the final 10–5 Old/New groups are 10/10, whereas the second update's preceding/new groups are 15/5. `voc10-5-stage-results.json` explicitly separates the fixed-base reported summary from `preceding_classes_miou` and `newly_added_classes_miou` in its derived summary. All-class mIoU is not an equal average of Old and New because class counts and background differ.

COCO-to-VOC first learns the 60 COCO categories that do not overlap VOC and then introduces the 20 VOC categories. COCO validation Old/New/All average 60 foreground, 20 foreground, and 81 including-background classes, respectively. `voc_new` is the separate new-class mIoU on VOC validation. No COCO category-ID map is included.

## Old-to-new prediction-error data

`step2-overwriting.csv` records final VOC 10–5 step-2 predictions. For each old class c (1–15), the rate is `100 × (# valid ground-truth c pixels predicted as any step-2 new class 16–20) / (# valid ground-truth c pixels)`. Baseline is the same-architecture baseline; CAPE is Baseline+CAPE; Full is EvoProto (CAPE+EBR). These are prediction errors relative to ground truth, not direct counts of training-target overwrite events. The 15-class arithmetic macro averages are 2.7477333333%, 0.7314666667%, and 0.6898%. They are not pooled pixel-weighted rates. Ground-truth pixel counts and prediction masks are not included, so the numerators and denominators cannot be reconstructed from this file alone. The corrected chair CAPE/Full values are 4.646%/3.579%.

## Reuse and validation

Use Python 3.8 or later with the standard library:

```
python validate_data.py
```

The script checks packaged-file SHA-256 hashes, validates the current source CSV/JSON structures and their stated numerical relationships, and prints the error-rate means. `checksums.sha256` covers all payload files other than itself. `provenance.json` distinguishes unchanged source files, author-corrected source files, and files transcribed from the manuscript. No original training process is reproduced by this validation.

## Coverage and unavailable material

This is an aggregate-results deposit with the data listed in the dictionary. It includes primary author-result summaries, per-class final and stage results, resource profiling, parameter sweeps, the old-to-new error rates, the shared-weight controls, manuscript-only prototype/confusion diagnostics, and VOC joint references. It does not redistribute VOC or COCO images, pixel masks, per-image model outputs, raw confusion matrices, learned prototype vectors, t-SNE embeddings, checkpoints, training code, raw timing traces, or per-seed runs. Existing figure-2 CAM/weight/matrix graphics are method illustrations and are not deposited as measured experimental data. Published third-party benchmark tables are also excluded from this results package. Individual predictions and the inputs used to compute manuscript-only aggregate diagnostics are not included.

The stage JSON retains both supplied summaries and recomputed summaries, with the final baseline summaries updated for the documented chair correction. Small differences can arise from rounding the per-class values. Reported precision varies by source row; retained extra decimal places do not represent uncertainty estimates.

## Repository and rights

The aggregate-results package is available at https://github.com/KaiXu47/EvoProto. Cite the exact repository revision used. A reuse license has not yet been selected. This deposit does not redistribute VOC/COCO images or change their original terms.
