"""Validate the packaged aggregates using only the Python standard library.

This checks file integrity and arithmetic, not the original training process.
"""
from pathlib import Path
from decimal import Decimal, ROUND_HALF_UP
import csv
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"


def read_csv(name):
    with (DATA / name).open(newline="", encoding="utf-8-sig") as stream:
        return list(csv.DictReader(stream))


def mean(values):
    values = list(values)
    return sum(values) / len(values)


def close(a, b, tol=1e-9):
    assert math.isclose(float(a), float(b), rel_tol=0, abs_tol=tol), (a, b)


def pct(value):
    assert 0 <= float(value) <= 100, value


def main():
    lines = (ROOT / "checksums.sha256").read_text(encoding="utf-8").splitlines()
    for line in lines:
        expected, relative = line.split("  ", 1)
        file = ROOT / relative
        assert file.is_file(), relative
        actual = hashlib.sha256(file.read_bytes()).hexdigest()
        assert actual == expected, "Checksum mismatch: " + relative
    provenance = json.loads((ROOT / "provenance.json").read_text(encoding="utf-8"))
    assert len(provenance["original_files"]) == 7
    corrected = [r for r in provenance["original_files"] if r["status"].startswith("Author-corrected")]
    unchanged = [r for r in provenance["original_files"] if r["status"] == "Unchanged author-supplied source"]
    assert len(corrected) == 3 and len(unchanged) == 4
    assert all(len(r["prior_sha256"]) == 64 and r["prior_sha256"] != r["sha256"] for r in corrected)
    assert provenance["correction_history"][0]["date"] == "2026-10-22"
    for record in provenance["original_files"]:
        assert hashlib.sha256((ROOT / record["file"]).read_bytes()).hexdigest() == record["sha256"]

    author_rows = read_csv("author-results.csv")
    complete = [r for r in author_rows if r["all"]]
    missing = [r for r in author_rows if not r["all"]]
    assert len(missing) == 2
    assert all(all(not r[m] for m in ("old", "new", "all")) for r in missing)
    for row in complete:
        for metric in ("old", "new", "all"):
            pct(row[metric])
    author = {r["method"]: r for r in complete if (r["dataset"], r["protocol"], r["task"]) == ("VOC", "overlap", "10-5")}
    final = json.loads((DATA / "evoproto-voc10-5.json").read_text(encoding="utf-8"))
    classes = list(final["class_iou"])
    assert classes[0] == "_background_" and len(classes) == 21
    close(final["all_miou"], mean(final["class_iou"].values()))
    close(final["foreground_miou"], mean(final["class_iou"][c] for c in classes[1:]))
    close(final["old_miou"], mean(final["class_iou"][c] for c in classes[1:11]))
    close(final["new_miou"], mean(final["class_iou"][c] for c in classes[11:]))
    for metric in ("old", "new", "all"):
        close(final[metric + "_miou"], author["EvoProto"][metric])

    baseline = read_csv("baseline-voc10-5.csv")
    base_classes = [r for r in baseline if r["class"] != "mIoU"]
    assert len(base_classes) == 21
    base_summary = [r for r in baseline if r["class"] == "mIoU"][0]
    for metric in ("CAM", "aux_CAM", "Seg_Pred"):
        for row in base_classes:
            pct(row[metric])
        close(base_summary[metric], mean(float(r[metric]) for r in base_classes), tol=0.001)
    close(mean(float(r["Seg_Pred"]) for r in base_classes[1:11]), author["Baseline (ViT)"]["old"])
    close(mean(float(r["Seg_Pred"]) for r in base_classes[11:]), author["Baseline (ViT)"]["new"])
    close(author["Baseline (ViT)"]["all"], mean(float(r["Seg_Pred"]) for r in base_classes), tol=0.001)
    baseline_by_class = {r["class"]: float(r["Seg_Pred"]) for r in base_classes}
    close(baseline_by_class["chair"], 39.7)
    close(author["Baseline (ViT)"]["old"], 74.924)
    close(author["Baseline (ViT)"]["all"], 68.298)

    stages = json.loads((DATA / "voc10-5-stage-results.json").read_text(encoding="utf-8"))
    groups = stages["class_groups"]
    assert len(groups["base10"]) == 10
    assert len(groups["step1_new"]) == len(groups["step2_new"]) == 5
    assert set(stages["stages"]) == {"0", "1", "2"}
    for step, methods in stages["stages"].items():
        assert set(methods) == {"Baseline", "EvoProto"}
        active_new = groups["step1_new"] + (groups["step2_new"] if step == "2" else [])
        for method, result in methods.items():
            values = result["class_iou"]
            assert len(values) == 11 + 5 * int(step)
            derived = result["derived_summary"]
            close(derived["all_miou"], mean(values.values()))
            close(derived["foreground_miou"], mean(v for k, v in values.items() if k != "background"))
            close(derived["base10_miou"], mean(values[c] for c in groups["base10"]))
            for key in ("all_miou", "foreground_miou"):
                if key in result["reported_summary"]:
                    close(result["reported_summary"][key], derived[key], tol=0.001)
            if step != "0":
                preceding = groups["base10"] + (groups["step1_new"] if step == "2" else [])
                current_new = groups["step1_new"] if step == "1" else groups["step2_new"]
                close(derived["preceding_classes_miou"], mean(values[c] for c in preceding))
                close(derived["newly_added_classes_miou"], mean(values[c] for c in current_new))
                close(result["reported_summary"]["old_miou"], derived["base10_miou"], tol=0.001)
                close(result["reported_summary"]["new_miou"], mean(values[c] for c in active_new), tol=0.001)
    for record in stages["pair_diagnostics"]:
        for method in ("Baseline", "EvoProto"):
            result = record[method]
            close(result["old_change"], result["old_after"] - result["old_before"])
    for row in base_classes:
        name = "background" if row["class"] == "_background_" else row["class"]
        close(row["Seg_Pred"], stages["stages"]["2"]["Baseline"]["class_iou"][name])
    for name, value in final["class_iou"].items():
        key = "background" if name == "_background_" else name
        close(value, stages["stages"]["2"]["EvoProto"]["class_iou"][key])

    errors = read_csv("step2-overwriting.csv")
    assert len(errors) == 15 and len({r["class"] for r in errors}) == 15
    means = {m: sum(Decimal(r[m]) for r in errors) / Decimal(15) for m in ("Baseline", "CAPE", "Full")}
    assert means["Baseline"].quantize(Decimal("0.000001")) == Decimal("2.747733")
    assert means["CAPE"].quantize(Decimal("0.000001")) == Decimal("0.731467")
    assert means["Full"] == Decimal("0.6898")
    chair = [r for r in errors if r["class"] == "chair"][0]
    assert chair["CAPE"] == "4.646" and chair["Full"] == "3.579"

    sweeps = read_csv("hyperparameter-sensitivity.csv")
    assert len(sweeps) == 15 and sum(int(r["is_default"]) for r in sweeps) == 4
    for row in sweeps:
        for metric in ("old", "new", "all"):
            expected = Decimal(author[row["source_method"]][metric]).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP)
            assert expected == Decimal(row[metric])
            reference = Decimal(author["EvoProto"][metric]).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP)
            assert Decimal(row["delta_" + metric]) == expected - reference

    resources = read_csv("resource-step1.csv")
    assert len(resources) == 2
    assert {r["method"] for r in resources} == {"Baseline", "EvoProto"}
    for row in resources:
        assert (row["stage"], row["device"], row["precision"], row["input_size"], row["batch_size"]) == ("step1", "RTX 4090", "FP32", "448x448", "8")
    controls = read_csv("shared-weight-controls.csv")
    assert len(controls) == 4
    assert [[r[m] for m in ("old_miou", "new_miou", "all_miou")] for r in controls] == [["78.0","64.6","72.3"],["78.7","65.8","73.2"],["78.3","65.0","72.6"],["79.2","66.9","74.0"]]
    assert all(r["data_status"] == "author-confirmed measured result" for r in controls)
    aggregates = read_csv("manuscript-aggregates.csv")
    assert len(aggregates) == 48
    chair_pairs = [r for r in aggregates if r["condition"] == "Weakly supervised" and r["class_pair"] == "chair / dining table" and r["metric"] == "pair miou"]
    assert len(chair_pairs) == 1
    pair_mean = (baseline_by_class["chair"] + baseline_by_class["diningtable"]) / 2
    close(chair_pairs[0]["value"], Decimal(str(pair_mean)).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP))
    for row in aggregates:
        if row["unit"].startswith("percent"):
            pct(row["value"])
    config = json.loads((DATA / "training-configuration.json").read_text(encoding="utf-8"))
    assert config["cam_thresholds"] == {"high":0.7, "low":0.25, "background":0.5}
    assert config["optimizer"]["weight_decay"] == 0.01
    print("PASS: {} payload-file checksums; 4 unchanged and 3 author-corrected source files; 10 data files.".format(len(lines)))
    print("PASS: CSV/JSON structure, per-class aggregates, stage/pair changes, and sweep deltas.")
    print("Old-to-new macro errors (%): " + ", ".join("{}={}".format(k, v) for k, v in means.items()))
    print("Shared-weight controls: 4 author-confirmed rows. Manuscript aggregate metrics: 48 rows.")
    print("Author correction 2026-10-22: baseline chair=39.7; Old/New/All=74.924/59.4519/68.298; chair/dining-table pair=37.1.")
    print("No original training, seeds, pixels, learned vectors, or raw matrices are reconstructed.")


if __name__ == "__main__":
    main()
